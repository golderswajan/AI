fixed_sequence = [1, 1, 1, 0, 0, 0, 0, 1]
print(fixed_sequence[1])
