a = '101'
print(a)
print(a[:1]+'1'+a[2:])